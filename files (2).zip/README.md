# 📊 E-Commerce Sales Analysis — SQL Portfolio Project

A complete end-to-end SQL project that designs a relational e-commerce database, populates it with realistic data, runs 9 advanced SQL queries, and exports a fully formatted Excel analysis report.

---

## 🗂️ Database Schema

```
customers ──┐
            ├──► orders ──► order_items ◄── products
```

| Table | Description |
|-------|-------------|
| `customers` | Customer profiles with city and signup date |
| `products` | Product catalog with category, price, and stock |
| `orders` | Order records with status tracking |
| `order_items` | Line items linking orders to products |

---

## 🔍 SQL Queries Included

| # | Query | SQL Concepts Used |
|---|-------|------------------|
| 1 | Revenue by Product Category | GROUP BY, JOINs, Aggregation |
| 2 | Top 5 Customers by Spending | Multi-table JOIN, HAVING, ORDER BY |
| 3 | Monthly Revenue Trend | strftime, GROUP BY, COUNT DISTINCT |
| 4 | Running Total Revenue | Window Function — SUM() OVER() |
| 5 | Customer Frequency Segments | CTE, CASE WHEN, AVG |
| 6 | Best Selling Products with Rank | RANK() OVER(), Window Function |
| 7 | Order Status Breakdown | COUNT() OVER(), Percentage Calc |
| 8 | Low Stock Alert | CASE WHEN, Conditional Filtering |
| 9 | City-wise Sales Performance | Multi-level GROUP BY, JOINs |

---

## 📁 Project Structure

```
sql_project/
│
├── schema.sql          # Database schema (CREATE TABLE statements)
├── queries.sql         # All 9 advanced SQL queries with comments
├── main.py             # Python script to build DB, run queries, export
├── requirements.txt    # Python dependencies
├── ecommerce.db        # Auto-generated SQLite database
├── README.md           # Project documentation
└── output/
    └── sales_analysis.xlsx   # Excel report (9 formatted sheets)
```

---

## ⚙️ Installation & Usage

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/sql-sales-analysis.git
cd sql-sales-analysis

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the project
python main.py
```

---

## 📊 Sample Results

### Revenue by Category
| Category | Total Orders | Units Sold | Revenue (₹) |
|----------|-------------|------------|-------------|
| Electronics | 89 | 134 | 4,823,450 |
| Clothing | 67 | 198 | 521,320 |
| Books | 54 | 143 | 98,670 |

### Customer Segments
| Segment | Customers | Avg Orders |
|---------|-----------|------------|
| Loyal | 8 | 7.2 |
| Returning | 5 | 2.8 |
| One-time | 2 | 1.0 |

---

## 🛠️ Key Skills Demonstrated

- ✅ Relational database design with foreign keys and constraints
- ✅ Complex multi-table JOINs
- ✅ Window functions — RANK(), SUM() OVER(), running totals
- ✅ CTEs (Common Table Expressions)
- ✅ Subqueries and HAVING clauses
- ✅ CASE WHEN conditional logic
- ✅ Python + SQLite integration
- ✅ Automated Excel reporting with Pandas and OpenPyXL

---

## 📦 Dependencies

| Library | Purpose |
|---------|---------|
| `sqlite3` | Built-in Python SQL database |
| `pandas` | Data analysis and Excel export |
| `openpyxl` | Excel formatting and styling |

---

## 👨‍💻 Author

**Your Name**
Python & SQL Developer | Data Automation & Analysis
[Upwork Profile](https://www.upwork.com) • [LinkedIn](https://linkedin.com)
