-- ============================================================
--  E-Commerce Sales Database — Advanced SQL Queries
--  Author  : Your Name
--  Skills  : Joins, Subqueries, Window Functions, CTEs, Aggregations
-- ============================================================


-- ── 1. TOTAL REVENUE BY CATEGORY ────────────────────────────────────────────
-- Shows which product categories generate the most revenue
SELECT
    p.category,
    COUNT(DISTINCT o.order_id)          AS total_orders,
    SUM(oi.quantity)                    AS units_sold,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS total_revenue
FROM order_items oi
JOIN products p  ON oi.product_id = p.product_id
JOIN orders   o  ON oi.order_id   = o.order_id
WHERE o.status != 'Cancelled'
GROUP BY p.category
ORDER BY total_revenue DESC;


-- ── 2. TOP 5 CUSTOMERS BY SPENDING ──────────────────────────────────────────
-- Identifies highest-value customers for loyalty programs
SELECT
    c.customer_id,
    c.full_name,
    c.city,
    COUNT(DISTINCT o.order_id)               AS total_orders,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS total_spent
FROM customers c
JOIN orders      o  ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
WHERE o.status = 'Delivered'
GROUP BY c.customer_id
ORDER BY total_spent DESC
LIMIT 5;


-- ── 3. MONTHLY REVENUE TREND ────────────────────────────────────────────────
-- Tracks revenue growth month by month
SELECT
    strftime('%Y-%m', o.order_date)          AS month,
    COUNT(DISTINCT o.order_id)               AS orders_count,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS monthly_revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status != 'Cancelled'
GROUP BY month
ORDER BY month;


-- ── 4. WINDOW FUNCTION — RUNNING TOTAL REVENUE ──────────────────────────────
-- Cumulative revenue over time using window function
SELECT
    strftime('%Y-%m', o.order_date)            AS month,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS monthly_revenue,
    ROUND(SUM(SUM(oi.quantity * oi.unit_price))
          OVER (ORDER BY strftime('%Y-%m', o.order_date)), 2) AS running_total
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status != 'Cancelled'
GROUP BY month
ORDER BY month;


-- ── 5. CTE — CUSTOMER ORDER FREQUENCY SEGMENTS ──────────────────────────────
-- Segments customers into frequency buckets using CTE
WITH customer_orders AS (
    SELECT
        c.customer_id,
        c.full_name,
        COUNT(o.order_id) AS order_count
    FROM customers c
    LEFT JOIN orders o ON c.customer_id = o.customer_id
    GROUP BY c.customer_id
)
SELECT
    CASE
        WHEN order_count = 0 THEN 'Inactive'
        WHEN order_count = 1 THEN 'One-time'
        WHEN order_count BETWEEN 2 AND 4 THEN 'Returning'
        ELSE 'Loyal'
    END                   AS segment,
    COUNT(*)              AS customer_count,
    ROUND(AVG(order_count), 1) AS avg_orders
FROM customer_orders
GROUP BY segment
ORDER BY avg_orders DESC;


-- ── 6. BEST SELLING PRODUCTS ─────────────────────────────────────────────────
-- Top 10 products by revenue with rank
SELECT
    RANK() OVER (ORDER BY SUM(oi.quantity * oi.unit_price) DESC) AS rank,
    p.product_name,
    p.category,
    SUM(oi.quantity)                           AS units_sold,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN orders   o ON oi.order_id   = o.order_id
WHERE o.status != 'Cancelled'
GROUP BY p.product_id
ORDER BY revenue DESC
LIMIT 10;


-- ── 7. ORDER STATUS BREAKDOWN ────────────────────────────────────────────────
-- Summary of order statuses with percentage
SELECT
    status,
    COUNT(*)                                        AS count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 1) AS percentage
FROM orders
GROUP BY status
ORDER BY count DESC;


-- ── 8. SUBQUERY — CUSTOMERS WHO SPENT ABOVE AVERAGE ─────────────────────────
-- Find customers whose spending exceeds the average customer spending
SELECT
    c.full_name,
    c.city,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS total_spent
FROM customers c
JOIN orders      o  ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
WHERE o.status = 'Delivered'
GROUP BY c.customer_id
HAVING total_spent > (
    SELECT AVG(customer_total)
    FROM (
        SELECT SUM(oi2.quantity * oi2.unit_price) AS customer_total
        FROM orders o2
        JOIN order_items oi2 ON o2.order_id = oi2.order_id
        WHERE o2.status = 'Delivered'
        GROUP BY o2.customer_id
    )
)
ORDER BY total_spent DESC;


-- ── 9. LOW STOCK ALERT ───────────────────────────────────────────────────────
-- Products running low on stock (less than 10 units)
SELECT
    product_id,
    product_name,
    category,
    stock_qty,
    CASE
        WHEN stock_qty = 0      THEN 'OUT OF STOCK'
        WHEN stock_qty < 5      THEN 'CRITICAL'
        WHEN stock_qty < 10     THEN 'LOW'
        ELSE                         'OK'
    END AS stock_status
FROM products
WHERE stock_qty < 10
ORDER BY stock_qty ASC;


-- ── 10. CITY-WISE SALES PERFORMANCE ─────────────────────────────────────────
-- Revenue breakdown by customer city
SELECT
    c.city,
    COUNT(DISTINCT c.customer_id)              AS customers,
    COUNT(DISTINCT o.order_id)                 AS total_orders,
    ROUND(SUM(oi.quantity * oi.unit_price), 2) AS total_revenue
FROM customers c
JOIN orders      o  ON c.customer_id = o.customer_id
JOIN order_items oi ON o.order_id    = oi.order_id
WHERE o.status != 'Cancelled'
GROUP BY c.city
ORDER BY total_revenue DESC;
