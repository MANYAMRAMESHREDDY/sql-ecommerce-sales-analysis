"""
E-Commerce Sales Analysis — SQL Portfolio Project
==================================================
Demonstrates: Database design, data insertion, advanced SQL queries,
              Python + SQLite integration, Pandas, Excel export.

Author : Your Name
Skills : Python, SQL, SQLite, Pandas, Data Analysis
"""

import sqlite3
import pandas as pd
import random
import os
from datetime import datetime, timedelta

# ── Config ─────────────────────────────────────────────────────────────────────
DB_PATH     = "ecommerce.db"
OUTPUT_DIR  = "output"
EXCEL_PATH  = f"{OUTPUT_DIR}/sales_analysis.xlsx"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Sample Data ────────────────────────────────────────────────────────────────
CUSTOMERS = [
    ("Arjun Sharma",    "arjun@email.com",    "Hyderabad"),
    ("Priya Reddy",     "priya@email.com",    "Bangalore"),
    ("Rahul Gupta",     "rahul@email.com",    "Mumbai"),
    ("Sneha Patel",     "sneha@email.com",    "Delhi"),
    ("Vikram Singh",    "vikram@email.com",   "Chennai"),
    ("Ananya Nair",     "ananya@email.com",   "Pune"),
    ("Rohan Mehta",     "rohan@email.com",    "Kolkata"),
    ("Deepa Kumar",     "deepa@email.com",    "Hyderabad"),
    ("Karan Joshi",     "karan@email.com",    "Bangalore"),
    ("Pooja Iyer",      "pooja@email.com",    "Mumbai"),
    ("Aditya Rao",      "aditya@email.com",   "Delhi"),
    ("Meera Das",       "meera@email.com",    "Chennai"),
    ("Suresh Verma",    "suresh@email.com",   "Pune"),
    ("Lakshmi Pillai",  "lakshmi@email.com",  "Hyderabad"),
    ("Nikhil Agarwal",  "nikhil@email.com",   "Mumbai"),
]

PRODUCTS = [
    ("iPhone 15",          "Electronics",   79999, 25),
    ("Samsung Galaxy S24", "Electronics",   69999, 30),
    ("Sony Headphones",    "Electronics",    8999, 50),
    ("Dell Laptop",        "Electronics",   55000, 15),
    ("Levi's Jeans",       "Clothing",       2999, 100),
    ("Nike Sneakers",      "Clothing",       5999, 80),
    ("Cotton T-Shirt",     "Clothing",        599, 200),
    ("Harry Potter Set",   "Books",          1499, 60),
    ("Python Cookbook",    "Books",           899, 45),
    ("SQL for Beginners",  "Books",           499, 40),
    ("Rice Cooker",        "Home & Kitchen", 2499, 35),
    ("Air Fryer",          "Home & Kitchen", 4999, 20),
    ("Face Wash",          "Beauty",          299, 150),
    ("Sunscreen SPF50",    "Beauty",          499, 120),
    ("Yoga Mat",           "Sports",         1299,  8),  # low stock
    ("Dumbbells 5kg",      "Sports",         1999,  3),  # critical stock
    ("Protein Powder",     "Sports",         2999,  0),  # out of stock
]

STATUSES = ["Delivered", "Delivered", "Delivered", "Shipped", "Pending", "Cancelled"]


# ── Build Database ─────────────────────────────────────────────────────────────
def build_database(conn):
    cur = conn.cursor()

    # Read and execute schema
    with open("schema.sql") as f:
        conn.executescript(f.read())

    # Insert customers
    base_date = datetime(2024, 1, 1)
    for i, (name, email, city) in enumerate(CUSTOMERS):
        signup = (base_date + timedelta(days=i * 12)).strftime("%Y-%m-%d")
        cur.execute(
            "INSERT OR IGNORE INTO customers (full_name, email, city, country, signup_date) VALUES (?,?,?,?,?)",
            (name, email, city, "India", signup)
        )

    # Insert products
    for name, cat, price, stock in PRODUCTS:
        cur.execute(
            "INSERT OR IGNORE INTO products (product_name, category, unit_price, stock_qty) VALUES (?,?,?,?)",
            (name, cat, price, stock)
        )

    # Insert orders + order items
    random.seed(42)
    order_start = datetime(2024, 1, 15)
    for i in range(120):
        customer_id = random.randint(1, len(CUSTOMERS))
        order_date  = (order_start + timedelta(days=i * 3)).strftime("%Y-%m-%d")
        status      = random.choice(STATUSES)
        cur.execute(
            "INSERT INTO orders (customer_id, order_date, status) VALUES (?,?,?)",
            (customer_id, order_date, status)
        )
        order_id = cur.lastrowid

        # 1–4 items per order
        num_items = random.randint(1, 4)
        products_in_order = random.sample(range(1, len(PRODUCTS) + 1), min(num_items, len(PRODUCTS)))
        for product_id in products_in_order:
            product_price = PRODUCTS[product_id - 1][2]
            qty           = random.randint(1, 3)
            cur.execute(
                "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?,?,?,?)",
                (order_id, product_id, qty, product_price)
            )

    conn.commit()
    print("✅ Database built — customers, products, orders, order_items loaded.")


# ── Run Queries ────────────────────────────────────────────────────────────────
def run_queries(conn):
    queries = {
        "1_Revenue_By_Category": """
            SELECT p.category,
                   COUNT(DISTINCT o.order_id)                    AS total_orders,
                   SUM(oi.quantity)                              AS units_sold,
                   ROUND(SUM(oi.quantity * oi.unit_price), 2)   AS total_revenue
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            JOIN orders   o ON oi.order_id   = o.order_id
            WHERE o.status != 'Cancelled'
            GROUP BY p.category
            ORDER BY total_revenue DESC
        """,
        "2_Top5_Customers": """
            SELECT c.full_name, c.city,
                   COUNT(DISTINCT o.order_id)                    AS total_orders,
                   ROUND(SUM(oi.quantity * oi.unit_price), 2)   AS total_spent
            FROM customers c
            JOIN orders      o  ON c.customer_id = o.customer_id
            JOIN order_items oi ON o.order_id    = oi.order_id
            WHERE o.status = 'Delivered'
            GROUP BY c.customer_id
            ORDER BY total_spent DESC
            LIMIT 5
        """,
        "3_Monthly_Revenue": """
            SELECT strftime('%Y-%m', o.order_date)               AS month,
                   COUNT(DISTINCT o.order_id)                    AS orders_count,
                   ROUND(SUM(oi.quantity * oi.unit_price), 2)   AS monthly_revenue
            FROM orders o
            JOIN order_items oi ON o.order_id = oi.order_id
            WHERE o.status != 'Cancelled'
            GROUP BY month
            ORDER BY month
        """,
        "4_Running_Total": """
            SELECT strftime('%Y-%m', o.order_date)                AS month,
                   ROUND(SUM(oi.quantity * oi.unit_price), 2)    AS monthly_revenue,
                   ROUND(SUM(SUM(oi.quantity * oi.unit_price))
                         OVER (ORDER BY strftime('%Y-%m', o.order_date)), 2) AS running_total
            FROM orders o
            JOIN order_items oi ON o.order_id = oi.order_id
            WHERE o.status != 'Cancelled'
            GROUP BY month
            ORDER BY month
        """,
        "5_Customer_Segments": """
            WITH customer_orders AS (
                SELECT c.customer_id, c.full_name,
                       COUNT(o.order_id) AS order_count
                FROM customers c
                LEFT JOIN orders o ON c.customer_id = o.customer_id
                GROUP BY c.customer_id
            )
            SELECT
                CASE
                    WHEN order_count = 0             THEN 'Inactive'
                    WHEN order_count = 1             THEN 'One-time'
                    WHEN order_count BETWEEN 2 AND 4 THEN 'Returning'
                    ELSE                                  'Loyal'
                END                        AS segment,
                COUNT(*)                   AS customer_count,
                ROUND(AVG(order_count), 1) AS avg_orders
            FROM customer_orders
            GROUP BY segment
            ORDER BY avg_orders DESC
        """,
        "6_Best_Selling_Products": """
            SELECT
                RANK() OVER (ORDER BY SUM(oi.quantity * oi.unit_price) DESC) AS rank,
                p.product_name, p.category,
                SUM(oi.quantity)                           AS units_sold,
                ROUND(SUM(oi.quantity * oi.unit_price), 2) AS revenue
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            JOIN orders   o ON oi.order_id   = o.order_id
            WHERE o.status != 'Cancelled'
            GROUP BY p.product_id
            ORDER BY revenue DESC
            LIMIT 10
        """,
        "7_Order_Status": """
            SELECT status,
                   COUNT(*) AS count,
                   ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 1) AS percentage
            FROM orders
            GROUP BY status
            ORDER BY count DESC
        """,
        "8_Low_Stock_Alert": """
            SELECT product_name, category, stock_qty,
                   CASE
                       WHEN stock_qty = 0  THEN 'OUT OF STOCK'
                       WHEN stock_qty < 5  THEN 'CRITICAL'
                       ELSE                     'LOW'
                   END AS stock_status
            FROM products
            WHERE stock_qty < 10
            ORDER BY stock_qty ASC
        """,
        "9_City_Sales": """
            SELECT c.city,
                   COUNT(DISTINCT c.customer_id)               AS customers,
                   COUNT(DISTINCT o.order_id)                  AS total_orders,
                   ROUND(SUM(oi.quantity * oi.unit_price), 2)  AS total_revenue
            FROM customers c
            JOIN orders      o  ON c.customer_id = o.customer_id
            JOIN order_items oi ON o.order_id    = oi.order_id
            WHERE o.status != 'Cancelled'
            GROUP BY c.city
            ORDER BY total_revenue DESC
        """,
    }

    results = {}
    for name, sql in queries.items():
        df = pd.read_sql_query(sql, conn)
        results[name] = df
        print(f"  ✅ {name.replace('_', ' ')} — {len(df)} rows")

    return results


# ── Export to Excel ────────────────────────────────────────────────────────────
def export_to_excel(results: dict):
    with pd.ExcelWriter(EXCEL_PATH, engine="openpyxl") as writer:
        for sheet_name, df in results.items():
            short_name = sheet_name[:31]  # Excel sheet name max 31 chars
            df.to_excel(writer, sheet_name=short_name, index=False)

            ws = writer.sheets[short_name]

            # Header styling
            from openpyxl.styles import PatternFill, Font, Alignment
            header_fill = PatternFill("solid", fgColor="1F4E79")
            for cell in ws[1]:
                cell.fill      = header_fill
                cell.font      = Font(bold=True, color="FFFFFF")
                cell.alignment = Alignment(horizontal="center")

            # Auto-fit columns
            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col) + 4
                ws.column_dimensions[col[0].column_letter].width = min(max_len, 40)

    print(f"\n💾 Excel report saved → {EXCEL_PATH}")


# ── Print Summary ──────────────────────────────────────────────────────────────
def print_summary(conn):
    cur = conn.cursor()
    total_revenue = cur.execute(
        "SELECT ROUND(SUM(oi.quantity * oi.unit_price), 2) FROM order_items oi "
        "JOIN orders o ON oi.order_id = o.order_id WHERE o.status != 'Cancelled'"
    ).fetchone()[0]

    total_orders   = cur.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
    total_customers = cur.execute("SELECT COUNT(*) FROM customers").fetchone()[0]
    total_products  = cur.execute("SELECT COUNT(*) FROM products").fetchone()[0]

    print("\n" + "="*50)
    print("       SALES ANALYSIS SUMMARY")
    print("="*50)
    print(f"  Total Customers   : {total_customers}")
    print(f"  Total Products    : {total_products}")
    print(f"  Total Orders      : {total_orders}")
    print(f"  Total Revenue     : ₹{total_revenue:,.2f}")
    print("="*50 + "\n")


# ── Main ───────────────────────────────────────────────────────────────────────
def main():
    print("\n📊 E-Commerce Sales Analysis — SQL Portfolio Project\n")

    # Remove old DB if exists
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = sqlite3.connect(DB_PATH)

    print("🔧 Building database...")
    build_database(conn)

    print("\n🔍 Running SQL queries...")
    results = run_queries(conn)

    print("\n📤 Exporting to Excel...")
    export_to_excel(results)

    print_summary(conn)
    conn.close()

    print("✅ Project complete! Check the 'output' folder.\n")


if __name__ == "__main__":
    main()
